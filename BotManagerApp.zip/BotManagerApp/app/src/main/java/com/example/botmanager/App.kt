package com.example.botmanager

import android.Manifest
import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.os.PowerManager
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/* ---------- डेटा स्टोर: ऐप और बैकग्राउंड सर्विस दोनों यही इस्तेमाल करते हैं ---------- */
object Store {
    private var sp: SharedPreferences? = null
    private var st = JSONObject()

    @Synchronized
    fun init(ctx: Context) {
        if (sp != null) return
        sp = ctx.applicationContext.getSharedPreferences("bot", Context.MODE_PRIVATE)
        st = try { JSONObject(sp!!.getString("st", "")!!) } catch (e: Exception) { fresh() }
    }

    private fun fresh() = JSONObject(
        """{"token":"","me":null,"enabled":false,"offset":0,
        "s":{"name":"मेरा बॉट","welcome":"नमस्ते! मैं आपकी क्या मदद कर सकता हूँ?",
        "unknown":"माफ़ कीजिए, यह कमांड मुझे समझ नहीं आई।","active":true},
        "cmds":{},"users":{},"logs":[]}"""
    )

    @Synchronized fun dump(): String = st.toString()

    @Synchronized fun <T> read(f: (JSONObject) -> T): T = f(st)

    @Synchronized
    fun mutate(f: (JSONObject) -> Unit) {
        f(st)
        sp!!.edit().putString("st", st.toString()).apply()
    }

    fun addLog(s: JSONObject, id: Long, text: String, kind: String = "msg") {
        val t = SimpleDateFormat("dd/MM HH:mm:ss", Locale.getDefault()).format(Date())
        val old = s.getJSONArray("logs")
        val n = JSONArray()
        n.put(JSONObject().put("t", t).put("id", id).put("text", text.take(300)).put("kind", kind))
        for (i in 0 until minOf(old.length(), 199)) n.put(old.get(i))
        s.put("logs", n)
    }
}

/* ---------- Telegram API ---------- */
fun api(method: String, body: String = "{}", readTimeout: Int = 15000): JSONObject {
    val token = Store.read { it.optString("token") }
    val c = URL("https://api.telegram.org/bot$token/$method").openConnection() as HttpURLConnection
    try {
        c.requestMethod = "POST"
        c.connectTimeout = 15000
        c.readTimeout = readTimeout
        c.doOutput = true
        c.setRequestProperty("Content-Type", "application/json")
        c.outputStream.use { it.write(body.toByteArray()) }
        val stream = if (c.responseCode < 400) c.inputStream else c.errorStream
        return JSONObject(stream.bufferedReader().use { it.readText() })
    } finally {
        c.disconnect()
    }
}

/* ---------- बैकग्राउंड सर्विस (Foreground Service) ---------- */
class BotService : Service() {
    companion object {
        @Volatile var gen = 0
    }

    private var wl: PowerManager.WakeLock? = null
    private var lastErr = 0L

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        Store.init(this)
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("bot", "बॉट", NotificationManager.IMPORTANCE_LOW))
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, "bot")
            .setContentTitle("बॉट चल रहा है")
            .setContentText("Telegram संदेशों का इंतज़ार")
            .setSmallIcon(android.R.drawable.stat_notify_chat)
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
        if (wl == null) {
            wl = getSystemService(PowerManager::class.java).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "botmgr:poll")
            wl!!.acquire()
        }
        gen += 1
        val g = gen
        Thread { loop(g) }.start()
        return START_STICKY
    }

    override fun onDestroy() {
        gen += 1
        wl?.release()
        wl = null
        super.onDestroy()
    }

    private fun loop(g: Int) {
        try { api("deleteWebhook") } catch (e: Exception) { }
        while (g == gen) {
            try {
                val off = Store.read { it.optLong("offset") }
                val r = api("getUpdates", """{"offset":$off,"timeout":25}""", 40000)
                if (!r.optBoolean("ok")) {
                    err("API एरर: " + r.optString("description"))
                    Thread.sleep(5000)
                    continue
                }
                val arr = r.getJSONArray("result")
                for (k in 0 until arr.length()) {
                    if (g != gen) return
                    val u = arr.getJSONObject(k)
                    try { handle(u) } catch (e: Exception) { err("handle एरर: " + e.message) }
                    Store.mutate { it.put("offset", u.getLong("update_id") + 1) }
                }
            } catch (e: Exception) {
                // इंटरनेट बंद हो तो लॉग न भरे; नेट आते ही अपने आप दोबारा जुड़ जाएगा
                err("नेटवर्क एरर: " + e.javaClass.simpleName)
                try { Thread.sleep(5000) } catch (x: InterruptedException) { }
            }
        }
    }

    private fun err(msg: String) {
        val now = System.currentTimeMillis()
        if (now - lastErr > 300000) {
            lastErr = now
            Store.mutate { Store.addLog(it, 0, msg, "error") }
        }
    }

    private fun handle(u: JSONObject) {
        val m = u.optJSONObject("message") ?: return
        val text = m.optString("text", "")
        if (text.isEmpty()) return
        val from = m.getJSONObject("from")
        val id = from.getLong("id").toString()
        var reply: String? = null
        Store.mutate { s ->
            val users = s.getJSONObject("users")
            if (!users.has(id)) {
                users.put(id, JSONObject()
                    .put("name", from.optString("first_name"))
                    .put("username", from.optString("username"))
                    .put("joined", SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(Date()))
                    .put("banned", false))
            }
            val banned = users.getJSONObject(id).optBoolean("banned")
            val set = s.getJSONObject("s")
            if (banned || !set.optBoolean("active", true)) return@mutate
            Store.addLog(s, id.toLong(), text)
            if (text.startsWith("/")) {
                val cmd = text.split(Regex("\\s"))[0].substring(1).substringBefore("@").lowercase()
                reply = if (cmd == "start") set.optString("welcome")
                else s.getJSONObject("cmds").optJSONObject(cmd)?.optString("reply") ?: set.optString("unknown")
            }
        }
        reply?.let {
            api("sendMessage", JSONObject().put("chat_id", m.getJSONObject("chat").getLong("id")).put("text", it).toString())
        }
    }
}

/* ---------- फ़ोन रीस्टार्ट के बाद अपने आप चालू ---------- */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, i: Intent) {
        Store.init(ctx)
        val go = Store.read { it.optBoolean("enabled") && it.optString("token").isNotEmpty() }
        if (go) ctx.startForegroundService(Intent(ctx, BotService::class.java))
    }
}

/* ---------- ऐप स्क्रीन (WebView में assets/index.html) ---------- */
class Bridge(private val act: Activity) {
    @JavascriptInterface fun getState(): String = Store.dump()

    @JavascriptInterface
    fun startBot() {
        Store.mutate { it.put("enabled", true) }
        act.startForegroundService(Intent(act, BotService::class.java))
    }

    @JavascriptInterface
    fun stopBot() {
        Store.mutate { it.put("enabled", false) }
        act.stopService(Intent(act, BotService::class.java))
    }

    @JavascriptInterface
    fun battery() {
        val pm = act.getSystemService(PowerManager::class.java)
        if (!pm.isIgnoringBatteryOptimizations(act.packageName)) {
            act.runOnUiThread {
                act.startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + act.packageName)))
            }
        }
    }

    @JavascriptInterface
    fun op(n: String, a: String, b: String, c: String) {
        Store.mutate { s ->
            when (n) {
                "token" -> { s.put("token", a); s.put("me", JSONObject(b)) }
                "settings" -> s.put("s", JSONObject(a))
                "addCmd" -> s.getJSONObject("cmds").put(a, JSONObject().put("reply", b).put("desc", c))
                "delCmd" -> s.getJSONObject("cmds").remove(a)
                "ban" -> s.getJSONObject("users").getJSONObject(a).let { it.put("banned", !it.optBoolean("banned")) }
                "clearLogs" -> s.put("logs", JSONArray())
                "log" -> Store.addLog(s, 0, a, b.ifEmpty { "broadcast" })
                "logout" -> { s.put("token", ""); s.put("me", JSONObject.NULL); s.put("enabled", false) }
                else -> {}
            }
        }
        if (n == "logout") act.stopService(Intent(act, BotService::class.java))
    }
}

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Store.init(this)
        val w = WebView(this)
        setContentView(w)
        w.settings.javaScriptEnabled = true
        w.settings.domStorageEnabled = true
        w.webChromeClient = WebChromeClient()
        w.addJavascriptInterface(Bridge(this), "Android")
        w.loadUrl("file:///android_asset/index.html")
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        moveTaskToBack(true)
    }
}
